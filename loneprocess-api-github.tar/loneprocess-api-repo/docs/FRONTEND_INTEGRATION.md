# API Credentials - För Frontend-teamet

## 🔑 Direktåtkomst till API:et

Detta dokument innehåller all information frontend-teamet behöver för att komma igång direkt.

## 📍 API Endpoints

### Development
```
Base URL: http://localhost:8000/api/v1
Health Check: http://localhost:8000/health
Documentation: http://localhost:8000/docs
```

### Production (när tillgänglig)
```
Base URL: https://api.loneprocess.se/api/v1
Health Check: https://api.loneprocess.se/health
```

## 🎫 Autentisering

### Development Token
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

### Användning i Headers
```javascript
{
  'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
  'Content-Type': 'application/json'
}
```

## 🚀 Snabbstart

### Vanilla JavaScript

```javascript
// API Configuration
const API_URL = 'http://localhost:8000/api/v1';
const API_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development';

// Fetch helper
async function apiRequest(endpoint, options = {}) {
  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${API_TOKEN}`,
      'Content-Type': 'application/json',
      ...options.headers
    }
  });
  
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  
  return response.json();
}

// Exempel: Hämta aktiviteter
async function getActivities() {
  const activities = await apiRequest('/activities');
  console.log(activities);
}

// Exempel: Skapa aktivitet
async function createActivity(data) {
  const activity = await apiRequest('/activities', {
    method: 'POST',
    body: JSON.stringify(data)
  });
  console.log('Created:', activity);
}
```

### React/Next.js

```typescript
// lib/api.ts
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
const API_TOKEN = process.env.NEXT_PUBLIC_API_TOKEN || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development';

export async function apiGet<T>(endpoint: string): Promise<T> {
  const response = await fetch(`${API_URL}${endpoint}`, {
    headers: {
      'Authorization': `Bearer ${API_TOKEN}`,
      'Content-Type': 'application/json'
    }
  });
  
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  
  return response.json();
}

export async function apiPost<T>(endpoint: string, data: any): Promise<T> {
  const response = await fetch(`${API_URL}${endpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
  
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  
  return response.json();
}

// Användning i component
import { apiGet } from '@/lib/api';

export default function ActivitiesPage() {
  const [activities, setActivities] = useState([]);
  
  useEffect(() => {
    apiGet('/activities').then(setActivities);
  }, []);
  
  return (
    <div>
      {activities.map(activity => (
        <div key={activity.id}>{activity.out_input}</div>
      ))}
    </div>
  );
}
```

### Vue.js

```javascript
// services/api.js
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';
const API_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development';

export const api = {
  async get(endpoint) {
    const response = await fetch(`${API_URL}${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${API_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });
    return response.json();
  },
  
  async post(endpoint, data) {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    return response.json();
  }
};

// Användning i component
import { api } from '@/services/api';

export default {
  data() {
    return {
      activities: []
    };
  },
  async mounted() {
    this.activities = await api.get('/activities');
  }
};
```

## 📋 TypeScript Definitions

```typescript
// types/api.ts

export interface Activity {
  id: number;
  process_nr: string | null;
  process: string | null;
  out_input: string | null;
  ska_inga_i_loneperiod: boolean;
  fas: number | null;
  roll: string | null;
  behov: string | null;
  effekten_vardet: string | null;
  extra_info: string | null;
  acceptans: string | null;
  feature_losning: string | null;
  priority: number | null;
  status: 'pending' | 'in_progress' | 'completed';
  created_at: string;
  updated_at: string | null;
}

export interface Loneperiod {
  id: number;
  name: string;
  start_date: string;
  end_date: string;
  status: 'planned' | 'active' | 'closed';
  completion_percentage: number;
  created_at: string;
  updated_at: string | null;
}

export interface LoneperiodProgress {
  loneperiod_id: number;
  completion_percentage: number;
  completed_count: number;
  total_count: number;
  pending_count: number;
  in_progress_count: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  bemannings_omrade_id: number | null;
  can_check_off: boolean;
  created_at: string;
}

export interface ApiError {
  error: {
    code: string;
    message: string;
    details?: any;
    timestamp: string;
  };
}
```

## 🔌 Vanliga API Calls

### 1. Hämta Alla Aktiviteter

```bash
curl -X GET "http://localhost:8000/api/v1/activities" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

```javascript
const activities = await fetch('http://localhost:8000/api/v1/activities', {
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
  }
}).then(r => r.json());
```

### 2. Filtrera Aktiviteter

```bash
curl -X GET "http://localhost:8000/api/v1/activities?role=Lönespecialist&status=pending" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

```javascript
const pendingActivities = await fetch(
  'http://localhost:8000/api/v1/activities?role=Lönespecialist&status=pending',
  {
    headers: {
      'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
    }
  }
).then(r => r.json());
```

### 3. Hämta Löneperiods Framdrift

```bash
curl -X GET "http://localhost:8000/api/v1/loneperiods/1/progress" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

```javascript
const progress = await fetch('http://localhost:8000/api/v1/loneperiods/1/progress', {
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
  }
}).then(r => r.json());

console.log(`Framdrift: ${progress.completion_percentage}%`);
```

### 4. Skapa Ny Aktivitet

```bash
curl -X POST "http://localhost:8000/api/v1/activities" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development" \
  -H "Content-Type: application/json" \
  -d '{
    "process_nr": "10.9",
    "out_input": "Ny aktivitet",
    "roll": "Lönespecialist",
    "ska_inga_i_loneperiod": true
  }'
```

```javascript
const newActivity = await fetch('http://localhost:8000/api/v1/activities', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    process_nr: '10.9',
    out_input: 'Ny aktivitet',
    roll: 'Lönespecialist',
    ska_inga_i_loneperiod: true
  })
}).then(r => r.json());
```

### 5. Uppdatera Aktivitet

```bash
curl -X PUT "http://localhost:8000/api/v1/activities/1" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development" \
  -H "Content-Type: application/json" \
  -d '{"status": "completed"}'
```

```javascript
const updated = await fetch('http://localhost:8000/api/v1/activities/1', {
  method: 'PUT',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ status: 'completed' })
}).then(r => r.json());
```

## 🎨 Exempel Use Cases

### Use Case 1: Dashboard med Framdrift

```javascript
async function loadDashboard() {
  // Hämta aktiv löneperiod
  const loneperiods = await fetch(
    'http://localhost:8000/api/v1/loneperiods?status=active',
    {
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
      }
    }
  ).then(r => r.json());
  
  const activePeriod = loneperiods[0];
  
  // Hämta framdrift
  const progress = await fetch(
    `http://localhost:8000/api/v1/loneperiods/${activePeriod.id}/progress`,
    {
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
      }
    }
  ).then(r => r.json());
  
  // Visa i UI
  document.getElementById('period-name').textContent = activePeriod.name;
  document.getElementById('progress-bar').style.width = `${progress.completion_percentage}%`;
  document.getElementById('completed-count').textContent = 
    `${progress.completed_count} av ${progress.total_count}`;
}
```

### Use Case 2: Lista Mina Aktiviteter

```javascript
async function loadMyActivities(role) {
  const activities = await fetch(
    `http://localhost:8000/api/v1/activities?role=${role}&status=pending`,
    {
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
      }
    }
  ).then(r => r.json());
  
  const list = document.getElementById('activities-list');
  list.innerHTML = activities.map(activity => `
    <div class="activity-card">
      <h3>${activity.out_input}</h3>
      <p>${activity.behov}</p>
      <button onclick="completeActivity(${activity.id})">Markera som klar</button>
    </div>
  `).join('');
}
```

## 🌐 Environment Variables

### .env.local (Next.js/React)
```env
NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
NEXT_PUBLIC_API_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

### .env (Vue/Vite)
```env
VITE_API_URL=http://localhost:8000/api/v1
VITE_API_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

## ❌ Error Handling

```javascript
async function apiRequest(endpoint, options = {}) {
  try {
    const response = await fetch(`http://localhost:8000/api/v1${endpoint}`, {
      ...options,
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || 'API Error');
    }
    
    return response.json();
  } catch (error) {
    console.error('API Request failed:', error);
    throw error;
  }
}
```

## 📞 Support

### Backend körs inte?
```bash
# Starta backend servern
cd backend
uvicorn app.main:app --reload
```

### CORS Error?
Se till att din frontend URL finns i `BACKEND_CORS_ORIGINS` i backend `.env`

### 401 Unauthorized?
Kontrollera att du inkluderar rätt token i Authorization header

### Frågor?
- **Dokumentation**: http://localhost:8000/docs
- **Backend Team**: Se README.md för kontaktinfo
- **Email**: support@loneprocess.se

## 🔄 API Status

### Health Check
```javascript
const health = await fetch('http://localhost:8000/health').then(r => r.json());
console.log(health); // { "status": "healthy", "version": "1.0.0" }
```

## 📚 Ytterligare Resurser

- **Fullständig API Dokumentation**: http://localhost:8000/docs
- **Integration Guide**: `docs/FRONTEND_INTEGRATION.md`
- **API Usage Guide**: `docs/API_USAGE_GUIDE.md`
- **GitHub Repository**: [länk när tillgänglig]

---

**Senast uppdaterad**: 2026-01-29  
**API Version**: 1.0.0  
**Backend Team Kontakt**: support@loneprocess.se
