# API Request/Response Examples

## Table of Contents
- [Activities](#activities)
- [Loneperiods](#loneperiods)
- [Common Patterns](#common-patterns)

---

## Activities

### 1. Get All Activities

**Request:**
```http
GET /api/v1/activities HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "process_nr": "10.1",
    "process": "Anställningsprocess",
    "out_input": "Nya anställningar",
    "ska_inga_i_loneperiod": true,
    "fas": null,
    "roll": "Lönespecialist",
    "behov": "Registera och komplettera nya anställningar",
    "effekten_vardet": "Inför varje löneperiod",
    "extra_info": null,
    "acceptans": "Jag är nöjd när anställningarna har kommit in",
    "feature_losning": "Genom att göra si eller så…",
    "priority": 1,
    "status": "pending",
    "created_at": "2026-01-29T10:00:00Z",
    "updated_at": null
  },
  {
    "id": 2,
    "process_nr": "10.2",
    "process": "Anställningsprocess",
    "out_input": "Anställningsförändringar",
    "ska_inga_i_loneperiod": true,
    "fas": null,
    "roll": "Lönespecialist",
    "behov": "Registera och komplettera anställningsförändringar",
    "effekten_vardet": "Inför varje löneperiod",
    "extra_info": null,
    "acceptans": null,
    "feature_losning": null,
    "priority": 1,
    "status": "pending",
    "created_at": "2026-01-29T10:00:00Z",
    "updated_at": null
  }
]
```

**cURL:**
```bash
curl -X GET "http://localhost:8000/api/v1/activities" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

**JavaScript (Fetch):**
```javascript
const response = await fetch('http://localhost:8000/api/v1/activities', {
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
  }
});
const activities = await response.json();
```

**Python:**
```python
import requests

response = requests.get(
    'http://localhost:8000/api/v1/activities',
    headers={
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
    }
)
activities = response.json()
```

---

### 2. Get Activity by ID

**Request:**
```http
GET /api/v1/activities/1 HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**Response (200 OK):**
```json
{
  "id": 1,
  "process_nr": "10.1",
  "process": "Anställningsprocess",
  "out_input": "Nya anställningar",
  "ska_inga_i_loneperiod": true,
  "fas": null,
  "roll": "Lönespecialist",
  "behov": "Registera och komplettera nya anställningar",
  "effekten_vardet": "Inför varje löneperiod",
  "extra_info": null,
  "acceptans": "Jag är nöjd när anställningarna har kommit in",
  "feature_losning": null,
  "priority": 1,
  "status": "pending",
  "created_at": "2026-01-29T10:00:00Z",
  "updated_at": null
}
```

**Response (404 Not Found):**
```json
{
  "error": {
    "code": "RESOURCE_NOT_FOUND",
    "message": "Aktivitet med ID 999 hittades inte",
    "details": {
      "resource_type": "activity",
      "resource_id": 999
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

---

### 3. Filter Activities

**Request:**
```http
GET /api/v1/activities?role=Lönespecialist&status=pending&limit=10 HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**cURL:**
```bash
curl -X GET "http://localhost:8000/api/v1/activities?role=Lönespecialist&status=pending&limit=10" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "roll": "Lönespecialist",
    "status": "pending",
    "out_input": "Nya anställningar",
    ...
  },
  {
    "id": 2,
    "roll": "Lönespecialist",
    "status": "pending",
    "out_input": "Anställningsförändringar",
    ...
  }
]
```

---

### 4. Create Activity

**Request:**
```http
POST /api/v1/activities HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
Content-Type: application/json

{
  "process_nr": "10.9",
  "process": "Custom Process",
  "out_input": "Ny test aktivitet",
  "roll": "Lönespecialist",
  "ska_inga_i_loneperiod": true,
  "behov": "Beskrivning av behov",
  "priority": 1,
  "status": "pending"
}
```

**Response (201 Created):**
```json
{
  "id": 42,
  "process_nr": "10.9",
  "process": "Custom Process",
  "out_input": "Ny test aktivitet",
  "ska_inga_i_loneperiod": true,
  "fas": null,
  "roll": "Lönespecialist",
  "behov": "Beskrivning av behov",
  "effekten_vardet": null,
  "extra_info": null,
  "acceptans": null,
  "feature_losning": null,
  "priority": 1,
  "status": "pending",
  "created_at": "2026-01-29T11:00:00Z",
  "updated_at": null
}
```

**cURL:**
```bash
curl -X POST "http://localhost:8000/api/v1/activities" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development" \
  -H "Content-Type: application/json" \
  -d '{
    "process_nr": "10.9",
    "out_input": "Ny test aktivitet",
    "roll": "Lönespecialist",
    "ska_inga_i_loneperiod": true
  }'
```

**JavaScript:**
```javascript
const response = await fetch('http://localhost:8000/api/v1/activities', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    process_nr: '10.9',
    out_input: 'Ny test aktivitet',
    roll: 'Lönespecialist',
    ska_inga_i_loneperiod: true
  })
});
const activity = await response.json();
```

**Response (422 Validation Error):**
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Valideringsfel i request",
    "details": [
      {
        "loc": ["body", "roll"],
        "msg": "field required",
        "type": "value_error.missing"
      }
    ],
    "timestamp": "2026-01-29T11:00:00Z"
  }
}
```

---

### 5. Update Activity

**Request:**
```http
PUT /api/v1/activities/1 HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
Content-Type: application/json

{
  "status": "completed",
  "priority": 2
}
```

**Response (200 OK):**
```json
{
  "id": 1,
  "process_nr": "10.1",
  "process": "Anställningsprocess",
  "out_input": "Nya anställningar",
  "ska_inga_i_loneperiod": true,
  "fas": null,
  "roll": "Lönespecialist",
  "behov": "Registera och komplettera nya anställningar",
  "effekten_vardet": "Inför varje löneperiod",
  "extra_info": null,
  "acceptans": "Jag är nöjd när anställningarna har kommit in",
  "feature_losning": null,
  "priority": 2,
  "status": "completed",
  "created_at": "2026-01-29T10:00:00Z",
  "updated_at": "2026-01-29T11:30:00Z"
}
```

**cURL:**
```bash
curl -X PUT "http://localhost:8000/api/v1/activities/1" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development" \
  -H "Content-Type: application/json" \
  -d '{"status": "completed"}'
```

---

### 6. Delete Activity

**Request:**
```http
DELETE /api/v1/activities/42 HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**Response (204 No Content):**
```
(No body)
```

**cURL:**
```bash
curl -X DELETE "http://localhost:8000/api/v1/activities/42" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

---

## Loneperiods

### 1. Get All Loneperiods

**Request:**
```http
GET /api/v1/loneperiods HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "Januari 2026",
    "start_date": "2026-01-01",
    "end_date": "2026-01-31",
    "status": "active",
    "completion_percentage": 75.5,
    "created_at": "2026-01-01T08:00:00Z",
    "updated_at": null
  },
  {
    "id": 2,
    "name": "Februari 2026",
    "start_date": "2026-02-01",
    "end_date": "2026-02-28",
    "status": "planned",
    "completion_percentage": 0.0,
    "created_at": "2026-01-15T08:00:00Z",
    "updated_at": null
  }
]
```

---

### 2. Filter Loneperiods by Status

**Request:**
```http
GET /api/v1/loneperiods?status=active HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**cURL:**
```bash
curl -X GET "http://localhost:8000/api/v1/loneperiods?status=active" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

---

### 3. Create Loneperiod

**Request:**
```http
POST /api/v1/loneperiods HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
Content-Type: application/json

{
  "name": "Mars 2026",
  "start_date": "2026-03-01",
  "end_date": "2026-03-31",
  "status": "planned"
}
```

**Response (201 Created):**
```json
{
  "id": 3,
  "name": "Mars 2026",
  "start_date": "2026-03-01",
  "end_date": "2026-03-31",
  "status": "planned",
  "completion_percentage": 0.0,
  "created_at": "2026-01-29T12:00:00Z",
  "updated_at": null
}
```

---

### 4. Get Loneperiod Progress

**Request:**
```http
GET /api/v1/loneperiods/1/progress HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
```

**Response (200 OK):**
```json
{
  "loneperiod_id": 1,
  "completion_percentage": 75.5,
  "completed_count": 30,
  "total_count": 40,
  "pending_count": 10
}
```

**cURL:**
```bash
curl -X GET "http://localhost:8000/api/v1/loneperiods/1/progress" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development"
```

**JavaScript:**
```javascript
const response = await fetch('http://localhost:8000/api/v1/loneperiods/1/progress', {
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
  }
});
const progress = await response.json();
console.log(`Completion: ${progress.completion_percentage}%`);
```

---

### 5. Add Activities to Loneperiod

**Request:**
```http
POST /api/v1/loneperiods/1/activities HTTP/1.1
Host: localhost:8000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development
Content-Type: application/json

{
  "activity_ids": [1, 2, 3, 4, 5]
}
```

**Response (201 Created):**
```json
{
  "message": "Lade till 5 aktiviteter till löneperiod",
  "added_count": 5
}
```

**cURL:**
```bash
curl -X POST "http://localhost:8000/api/v1/loneperiods/1/activities" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development" \
  -H "Content-Type: application/json" \
  -d '{"activity_ids": [1, 2, 3, 4, 5]}'
```

---

## Common Patterns

### Pagination

```http
GET /api/v1/activities?skip=20&limit=10 HTTP/1.1
```

**JavaScript implementation:**
```javascript
async function getAllActivities() {
  let allActivities = [];
  let skip = 0;
  const limit = 100;

  while (true) {
    const response = await fetch(
      `http://localhost:8000/api/v1/activities?skip=${skip}&limit=${limit}`,
      {
        headers: {
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development'
        }
      }
    );
    
    const activities = await response.json();
    allActivities = allActivities.concat(activities);
    
    if (activities.length < limit) break;
    skip += limit;
  }

  return allActivities;
}
```

### Error Handling

```javascript
async function safeApiCall(url, options = {}) {
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('API Error:', error.error.message);
      throw new Error(error.error.message);
    }

    return response.json();
  } catch (err) {
    console.error('Network error:', err);
    throw err;
  }
}

// Usage
try {
  const activity = await safeApiCall('http://localhost:8000/api/v1/activities/1');
} catch (error) {
  // Handle error
}
```

### Batch Operations

**Create multiple activities:**
```javascript
async function createMultipleActivities(activities) {
  const promises = activities.map(activity =>
    fetch('http://localhost:8000/api/v1/activities', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token_for_development',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(activity)
    }).then(r => r.json())
  );

  return Promise.all(promises);
}

// Usage
const newActivities = await createMultipleActivities([
  { process_nr: '10.9', out_input: 'Activity 1', roll: 'Lönespecialist' },
  { process_nr: '10.10', out_input: 'Activity 2', roll: 'Lönechef' }
]);
```

---

## Health Check

**Request:**
```http
GET /health HTTP/1.1
Host: localhost:8000
```

**Response (200 OK):**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "service": "Löneprocess Digital Checklista API"
}
```

**cURL:**
```bash
curl http://localhost:8000/health
```
