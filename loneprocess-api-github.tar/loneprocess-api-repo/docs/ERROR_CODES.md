# API Error Codes Documentation

## Overview

API:et använder standardiserade felkoder och HTTP status codes för att indikera framgång eller fel i requests. Alla felsvar följer samma struktur för konsistens.

## Error Response Format

Alla fel returneras i följande format:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Mänskligt läsbart felmeddelande",
    "details": {
      "extra": "information"
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

### Fields

- **code** (string): Maskinläsbar felkod som identifierar feltypen
- **message** (string): Mänskligt läsbart meddelande som beskriver felet
- **details** (object, optional): Ytterligare information om felet
- **timestamp** (string): ISO 8601 tidsstämpel när felet inträffade

---

## HTTP Status Codes

### Success Codes

| Status Code | Meaning | Usage |
|------------|---------|-------|
| 200 | OK | Lyckad GET/PUT/PATCH request |
| 201 | Created | Lyckad POST request, ny resurs skapad |
| 204 | No Content | Lyckad DELETE request, ingen body returneras |

### Client Error Codes (4xx)

| Status Code | Meaning | Usage |
|------------|---------|-------|
| 400 | Bad Request | Ogiltig request syntax eller semantik |
| 401 | Unauthorized | Autentisering krävs eller misslyckades |
| 403 | Forbidden | Autentiserad men otillräcklig behörighet |
| 404 | Not Found | Resursen finns inte |
| 422 | Unprocessable Entity | Valideringsfel i request data |
| 429 | Too Many Requests | Rate limit överskreds |

### Server Error Codes (5xx)

| Status Code | Meaning | Usage |
|------------|---------|-------|
| 500 | Internal Server Error | Oväntat serverfel |
| 503 | Service Unavailable | Tjänsten är tillfälligt otillgänglig |

---

## Error Codes Reference

### VALIDATION_ERROR (422)

Request innehåller ogiltig data som inte uppfyller valideringskrav.

**HTTP Status:** 422 Unprocessable Entity

**Example:**
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Valideringsfel i request",
    "details": [
      {
        "loc": ["body", "name"],
        "msg": "field required",
        "type": "value_error.missing"
      },
      {
        "loc": ["body", "priority"],
        "msg": "ensure this value is greater than or equal to 1",
        "type": "value_error.number.not_ge"
      }
    ],
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Saknade obligatoriska fält
- Felaktig datatyp (t.ex. string istället för integer)
- Värde utanför tillåtet intervall
- Ogiltig email-format
- Datum i fel format

**How to fix:**
- Kontrollera att alla required fields finns med
- Verifiera datatyper matchar schema
- Se till att värden är inom tillåtna gränser
- Använd rätt datum/email format

---

### RESOURCE_NOT_FOUND (404)

Den begärda resursen finns inte.

**HTTP Status:** 404 Not Found

**Example:**
```json
{
  "error": {
    "code": "RESOURCE_NOT_FOUND",
    "message": "Aktivitet med ID 123 hittades inte",
    "details": {
      "resource_type": "activity",
      "resource_id": 123
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Felaktigt ID i URL
- Resursen har tagits bort
- ID existerar inte i databasen

**How to fix:**
- Verifiera att ID:t är korrekt
- Använd GET endpoint för att lista tillgängliga resurser
- Kontrollera att resursen inte har tagits bort

---

### DUPLICATE_RESOURCE (400)

Försök att skapa en resurs som redan existerar.

**HTTP Status:** 400 Bad Request

**Example:**
```json
{
  "error": {
    "code": "DUPLICATE_RESOURCE",
    "message": "En löneperiod med namnet 'Januari 2026' finns redan",
    "details": {
      "resource_type": "loneperiod",
      "field": "name",
      "value": "Januari 2026"
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Försök att skapa löneperiod med existerande namn
- Försök att skapa användare med existerande email
- Unika constraints brytes

**How to fix:**
- Använd annat namn/värde för unikt fält
- Uppdatera befintlig resurs istället (PUT)
- Kontrollera existerande resurser först

---

### UNAUTHORIZED (401)

Autentisering krävs eller token är ogiltig.

**HTTP Status:** 401 Unauthorized

**Example:**
```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Autentisering krävs för denna operation",
    "details": {
      "reason": "missing_token"
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Authorization header saknas
- Token är ogiltig eller utgången
- Token format är felaktigt

**How to fix:**
- Inkludera Authorization header: `Bearer <token>`
- Verifiera att token är giltig
- Hämta ny token om den har utgått

---

### FORBIDDEN (403)

Autentiserad men saknar behörighet för operationen.

**HTTP Status:** 403 Forbidden

**Example:**
```json
{
  "error": {
    "code": "FORBIDDEN",
    "message": "Du har inte behörighet att utföra denna operation",
    "details": {
      "required_permission": "can_check_off",
      "user_role": "viewer"
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Användare har fel roll
- Saknar specifik behörighet
- Försök att ändra resurser i annat bemanningsområde

**How to fix:**
- Kontakta administratör för behörigheter
- Använd konto med rätt roll
- Verifiera att du har tillgång till resursen

---

### RATE_LIMIT_EXCEEDED (429)

För många requests under kort tid.

**HTTP Status:** 429 Too Many Requests

**Example:**
```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Du har överskridit rate limit på 100 requests per minut",
    "details": {
      "limit": 100,
      "window": "60 seconds",
      "retry_after": 45
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- För många API calls i följd
- Loopar utan delay
- Bulk operations utan batch endpoints

**How to fix:**
- Implementera exponential backoff
- Vänta tills `retry_after` sekunder
- Använd batch endpoints när möjligt
- Cacha data för att minska antal requests

---

### INTERNAL_ERROR (500)

Oväntat serverfel.

**HTTP Status:** 500 Internal Server Error

**Example:**
```json
{
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "Ett oväntat fel inträffade. Vänligen försök igen senare.",
    "details": {},
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Databasfel
- Oväntat exception i backend
- Timeout

**How to fix:**
- Försök igen efter en kort stund
- Kontakta support om problemet kvarstår
- Kontrollera status på /health endpoint

---

### DATABASE_ERROR (500)

Databasrelaterat fel.

**HTTP Status:** 500 Internal Server Error

**Example:**
```json
{
  "error": {
    "code": "DATABASE_ERROR",
    "message": "Ett databasfel inträffade",
    "details": {
      "operation": "insert"
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Databaskoppling bruten
- Query timeout
- Databasserverfel

**How to fix:**
- Försök igen
- Kontakta support om problemet kvarstår

---

### INVALID_FILTER (400)

Ogiltig filtreringsparameter.

**HTTP Status:** 400 Bad Request

**Example:**
```json
{
  "error": {
    "code": "INVALID_FILTER",
    "message": "Ogiltigt värde för status filter",
    "details": {
      "field": "status",
      "value": "invalid_status",
      "allowed_values": ["pending", "in_progress", "completed"]
    },
    "timestamp": "2026-01-29T10:30:00Z"
  }
}
```

**Common causes:**
- Ogiltigt enum värde
- Fel filter namn
- Felaktig datatyp för filter

**How to fix:**
- Använd tillåtna värden för filter
- Se API dokumentation för giltiga filter

---

## Error Handling Best Practices

### 1. Always Check Status Code

```javascript
const response = await fetch(url);
if (!response.ok) {
  const error = await response.json();
  // Handle error based on error.error.code
}
```

### 2. Handle Specific Error Codes

```javascript
try {
  const response = await fetch(url);
  if (!response.ok) {
    const error = await response.json();
    
    switch (error.error.code) {
      case 'RESOURCE_NOT_FOUND':
        console.log('Resource not found');
        break;
      case 'VALIDATION_ERROR':
        console.log('Validation failed:', error.error.details);
        break;
      case 'UNAUTHORIZED':
        // Redirect to login
        break;
      default:
        console.error('Unknown error:', error.error.message);
    }
  }
} catch (err) {
  console.error('Network error:', err);
}
```

### 3. Implement Retry Logic

```javascript
async function apiCallWithRetry(url, options = {}, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, options);
      
      if (response.ok) {
        return await response.json();
      }
      
      const error = await response.json();
      
      // Don't retry client errors (4xx except 429)
      if (response.status >= 400 && response.status < 500 && response.status !== 429) {
        throw error;
      }
      
      // Retry on 429 or 5xx
      if (i < maxRetries - 1) {
        const delay = Math.pow(2, i) * 1000; // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    } catch (err) {
      if (i === maxRetries - 1) throw err;
    }
  }
}
```

### 4. Display User-Friendly Messages

```javascript
function getErrorMessage(errorCode) {
  const messages = {
    'RESOURCE_NOT_FOUND': 'Den begärda resursen hittades inte.',
    'VALIDATION_ERROR': 'Vänligen kontrollera att alla fält är korrekt ifyllda.',
    'UNAUTHORIZED': 'Du måste logga in för att utföra denna operation.',
    'FORBIDDEN': 'Du har inte behörighet för denna operation.',
    'RATE_LIMIT_EXCEEDED': 'För många förfrågningar. Vänligen vänta en stund.',
    'INTERNAL_ERROR': 'Ett oväntat fel inträffade. Försök igen senare.'
  };
  
  return messages[errorCode] || 'Ett fel inträffade. Försök igen.';
}

// Usage
try {
  const response = await fetch(url);
  if (!response.ok) {
    const error = await response.json();
    alert(getErrorMessage(error.error.code));
  }
} catch (err) {
  alert('Nätverksfel. Kontrollera din internetanslutning.');
}
```

### 5. Log Errors for Debugging

```javascript
async function apiCall(url, options = {}) {
  try {
    const response = await fetch(url, options);
    
    if (!response.ok) {
      const error = await response.json();
      
      // Log error details
      console.error('API Error:', {
        code: error.error.code,
        message: error.error.message,
        details: error.error.details,
        timestamp: error.error.timestamp,
        url: url,
        method: options.method || 'GET'
      });
      
      throw error;
    }
    
    return await response.json();
  } catch (err) {
    console.error('Request failed:', err);
    throw err;
  }
}
```

---

## Rate Limiting

### Limits

- **Per User:** 100 requests per minute
- **Per User:** 1000 requests per day

### Rate Limit Headers

Responses include rate limit information in headers:

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1643461200
```

### Handling Rate Limits

```javascript
async function apiCallWithRateLimit(url, options = {}) {
  const response = await fetch(url, options);
  
  // Check rate limit headers
  const limit = response.headers.get('X-RateLimit-Limit');
  const remaining = response.headers.get('X-RateLimit-Remaining');
  const reset = response.headers.get('X-RateLimit-Reset');
  
  console.log(`Rate limit: ${remaining}/${limit} remaining`);
  
  if (response.status === 429) {
    const error = await response.json();
    const retryAfter = error.error.details.retry_after || 60;
    
    console.log(`Rate limited. Retry after ${retryAfter} seconds`);
    
    // Wait and retry
    await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
    return apiCallWithRateLimit(url, options);
  }
  
  return response.json();
}
```

---

## Support

Om du stöter på fel som inte är dokumenterade här eller behöver hjälp:

- **Email:** support@loneprocess.se
- **Dokumentation:** http://localhost:8000/docs
- **Health Status:** http://localhost:8000/health

Vid felanmälan, inkludera:
- Error code
- Timestamp
- Request details (URL, method, body)
- Expected behavior
